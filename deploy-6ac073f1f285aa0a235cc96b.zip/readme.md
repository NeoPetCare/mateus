# NeoPetCare

Aplicacao web com frontend estatico e API Node.js para os fluxos publicos da plataforma.

## Executar localmente

Requer Node.js 20 ou superior e PostgreSQL 14 ou superior.

Crie um banco e um usuário no PostgreSQL, depois configure `DATABASE_URL` com base em [.env.example](.env.example). O schema é aplicado automaticamente ao iniciar.

```powershell
cd E:\neopetcare\neopetcare
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
npm.cmd install
npm.cmd run check
npm.cmd start
```

Abra `http://localhost:3000`. O servidor entrega a interface de `../html site` e a API no mesmo endereço.
Antes de iniciar, ajuste `DATABASE_URL` no `.env` com as credenciais do seu PostgreSQL.

## API

- `GET /api/health`
- `GET /api/me`
- `POST /api/auth/signup`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `POST /api/newsletter`
- `POST /api/adoptions`
- `GET/POST /api/reports`
- `POST /api/donations` (registra intenção; não processa pagamento)
- `GET/POST /api/wiki/articles`
- `POST /api/testimonials` (envia para revisão)

Os dados são persistidos no PostgreSQL. O arquivo [db/schema.sql](db/schema.sql) é idempotente e aplicado automaticamente pelo servidor.

## Netlify Database

No Netlify, os dados ficam no Netlify Database (Postgres gerenciado). As tabelas são definidas em [db/schema.ts](db/schema.ts) com Drizzle ORM e a API roda como Netlify Function em [netlify/functions/api.ts](netlify/functions/api.ts), atendendo às mesmas rotas `/api/*`. As sessões de login também ficam no banco (tabela `sessions`).

Para alterar o schema, edite `db/schema.ts` e gere uma migração com `npx drizzle-kit generate --name <descricao>`. As migrações em `netlify/database/migrations/` são aplicadas automaticamente a cada deploy.

## Producao

Defina `NODE_ENV=production` para ativar cookies `Secure`. As sessões ainda ficam em memória no processo Node; em produção com mais de uma instância, use Redis ou outro armazenamento compartilhado. Use HTTPS, proxy reverso, backups do PostgreSQL, monitoramento e rotação de segredos antes de publicar.
