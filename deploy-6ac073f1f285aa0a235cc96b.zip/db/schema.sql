CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS newsletter (
  email VARCHAR(254) PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS adoptions (
  id TEXT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  city VARCHAR(100) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  pet VARCHAR(80) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  status VARCHAR(20) NOT NULL CHECK (status IN ('perdido', 'encontrado')),
  name VARCHAR(100) NOT NULL,
  animal VARCHAR(40) NOT NULL,
  location VARCHAR(150) NOT NULL,
  description VARCHAR(1000) NOT NULL,
  photo TEXT,
  date DATE NOT NULL,
  date_label VARCHAR(40) NOT NULL DEFAULT 'agora',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE reports ADD COLUMN IF NOT EXISTS photo TEXT;

CREATE TABLE IF NOT EXISTS donations (
  id TEXT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wiki_articles (
  id TEXT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  category VARCHAR(20) NOT NULL CHECK (category IN ('saude', 'cuidados', 'adocao', 'direitos')),
  author VARCHAR(100) NOT NULL,
  summary VARCHAR(1000) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS testimonials (
  id TEXT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  role VARCHAR(120) NOT NULL,
  text VARCHAR(2000) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'em-analise' CHECK (status IN ('em-analise', 'aprovado')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS reports_created_at_idx ON reports (created_at DESC);
CREATE INDEX IF NOT EXISTS wiki_articles_created_at_idx ON wiki_articles (created_at DESC);
CREATE INDEX IF NOT EXISTS testimonials_created_at_idx ON testimonials (created_at DESC);