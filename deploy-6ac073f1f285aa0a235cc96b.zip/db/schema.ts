import { sql } from "drizzle-orm";
import { check, date, index, integer, pgTable, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: text().primaryKey(),
  name: varchar({ length: 100 }).notNull(),
  email: varchar({ length: 254 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    token: text().primaryKey(),
    userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sessions_user_id_idx").on(table.userId)]
);

export const newsletter = pgTable("newsletter", {
  email: varchar({ length: 254 }).primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const adoptions = pgTable("adoptions", {
  id: text().primaryKey(),
  name: varchar({ length: 100 }).notNull(),
  phone: varchar({ length: 30 }).notNull(),
  city: varchar({ length: 100 }).notNull(),
  message: varchar({ length: 1000 }).notNull(),
  pet: varchar({ length: 80 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reports = pgTable(
  "reports",
  {
    id: text().primaryKey(),
    status: varchar({ length: 20 }).notNull(),
    name: varchar({ length: 100 }).notNull(),
    animal: varchar({ length: 40 }).notNull(),
    location: varchar({ length: 150 }).notNull(),
    description: varchar({ length: 1000 }).notNull(),
    photo: text(),
    date: date().notNull(),
    dateLabel: varchar("date_label", { length: 40 }).notNull().default("agora"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("reports_status_check", sql`${table.status} IN ('perdido', 'encontrado')`),
    index("reports_created_at_idx").on(table.createdAt.desc()),
  ]
);

export const donations = pgTable(
  "donations",
  {
    id: text().primaryKey(),
    name: varchar({ length: 100 }).notNull(),
    email: varchar({ length: 254 }).notNull(),
    amountCents: integer("amount_cents").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [check("donations_amount_cents_check", sql`${table.amountCents} > 0`)]
);

export const wikiArticles = pgTable(
  "wiki_articles",
  {
    id: text().primaryKey(),
    title: varchar({ length: 180 }).notNull(),
    category: varchar({ length: 20 }).notNull(),
    author: varchar({ length: 100 }).notNull(),
    summary: varchar({ length: 1000 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("wiki_articles_category_check", sql`${table.category} IN ('saude', 'cuidados', 'adocao', 'direitos')`),
    index("wiki_articles_created_at_idx").on(table.createdAt.desc()),
  ]
);

export const testimonials = pgTable(
  "testimonials",
  {
    id: text().primaryKey(),
    name: varchar({ length: 100 }).notNull(),
    role: varchar({ length: 120 }).notNull(),
    text: varchar({ length: 2000 }).notNull(),
    status: varchar({ length: 20 }).notNull().default("em-analise"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check("testimonials_status_check", sql`${table.status} IN ('em-analise', 'aprovado')`),
    index("testimonials_created_at_idx").on(table.createdAt.desc()),
  ]
);
