import type { Config, Context } from "@netlify/functions";
import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, count, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { adoptions, donations, newsletter, reports, sessions, testimonials, users, wikiArticles } from "../../db/schema.js";

const scrypt = promisify(scryptCallback) as (password: string, salt: string, keylen: number) => Promise<Buffer>;
const SESSION_TTL_MS = 86_400_000;

type PublicUser = { id: string; name: string; email: string };

function json(status: number, body: unknown, extraHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extraHeaders },
  });
}

function cleanText(value: unknown, maxLength = 500) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function validEmail(value: unknown): value is string {
  return typeof value === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 254;
}

function validDonationAmount(value: number) {
  return Number.isInteger(value) && [2500, 5000, 10000, 25000].includes(value);
}

function validWikiCategory(value: string) {
  return ["saude", "cuidados", "adocao", "direitos"].includes(value);
}

function publicUser(user: PublicUser | null | undefined) {
  return user ? { id: user.id, name: user.name, email: user.email } : null;
}

function createId() {
  return randomBytes(16).toString("hex");
}

async function createPasswordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = await scrypt(password, salt, 64);
  return `${salt}:${Buffer.from(derivedKey).toString("hex")}`;
}

async function passwordMatches(password: string, storedHash: string) {
  const [salt, storedKey] = String(storedHash).split(":");
  if (!salt || !storedKey) return false;
  const derivedKey = Buffer.from(await scrypt(password, salt, 64));
  const expectedKey = Buffer.from(storedKey, "hex");
  return expectedKey.length === derivedKey.length && timingSafeEqual(expectedKey, derivedKey);
}

function sessionCookie(token: string, secure: boolean) {
  return `sid=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${secure ? "; Secure" : ""}`;
}

async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  await db.insert(sessions).values({ token, userId, expiresAt: new Date(Date.now() + SESSION_TTL_MS) });
  return token;
}

async function currentUser(token: string | undefined) {
  if (!token) return null;
  const [row] = await db
    .select({ id: users.id, name: users.name, email: users.email })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())));
  return row || null;
}

const reportColumns = {
  id: reports.id,
  status: reports.status,
  name: reports.name,
  animal: reports.animal,
  location: reports.location,
  description: reports.description,
  photo: reports.photo,
  date: reports.date,
  dateLabel: reports.dateLabel,
  createdAt: reports.createdAt,
};

const articleColumns = {
  id: wikiArticles.id,
  title: wikiArticles.title,
  category: wikiArticles.category,
  author: wikiArticles.author,
  summary: wikiArticles.summary,
  createdAt: wikiArticles.createdAt,
};

export default async (req: Request, context: Context) => {
  const url = new URL(req.url);
  const route = url.pathname.replace(/\/+$/, "");
  const secure = url.protocol === "https:";

  if (req.method !== "GET") {
    if (!String(req.headers.get("content-type") || "").startsWith("application/json")) {
      return json(415, { error: "A requisição deve usar application/json." });
    }
    const requestOrigin = req.headers.get("origin");
    if (requestOrigin && requestOrigin !== url.origin) return json(403, { error: "Origem não autorizada." });
  }

  try {
    const token = context.cookies.get("sid");

    if (req.method === "GET" && route === "/api/health") return json(200, { ok: true });
    if (req.method === "GET" && route === "/api/me") return json(200, { user: publicUser(await currentUser(token)) });

    let body: Record<string, unknown> = {};
    if (req.method !== "GET") {
      const raw = await req.text();
      if (raw.length > 4_194_304) return json(413, { error: "Corpo da requisição inválido." });
      try {
        body = raw ? JSON.parse(raw) : {};
      } catch {
        return json(400, { error: "Corpo da requisição inválido." });
      }
    }

    if (req.method === "POST" && route === "/api/auth/signup") {
      const name = cleanText(body.name, 100);
      const email = cleanText(body.email, 254).toLowerCase();
      const password = typeof body.password === "string" ? body.password : "";
      if (name.length < 2 || !validEmail(email) || password.length < 8 || password.length > 128) {
        return json(400, { error: "Informe nome, e-mail válido e senha de 8 a 128 caracteres." });
      }
      const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email));
      if (existing) return json(409, { error: "Este e-mail já está cadastrado." });
      const newUser = { id: createId(), name, email, passwordHash: await createPasswordHash(password) };
      await db.insert(users).values(newUser);
      const sessionToken = await createSession(newUser.id);
      return json(201, { user: publicUser(newUser) }, { "Set-Cookie": sessionCookie(sessionToken, secure) });
    }

    if (req.method === "POST" && route === "/api/auth/login") {
      const email = cleanText(body.email, 254).toLowerCase();
      const password = typeof body.password === "string" ? body.password : "";
      const [account] = await db.select().from(users).where(eq(users.email, email));
      if (!account || !(await passwordMatches(password, account.passwordHash))) {
        return json(401, { error: "E-mail ou senha inválidos." });
      }
      const sessionToken = await createSession(account.id);
      return json(200, { user: publicUser(account) }, { "Set-Cookie": sessionCookie(sessionToken, secure) });
    }

    if (req.method === "POST" && route === "/api/auth/logout") {
      if (token) await db.delete(sessions).where(eq(sessions.token, token));
      return json(200, { ok: true }, { "Set-Cookie": "sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0" });
    }

    if (req.method === "POST" && route === "/api/newsletter") {
      const email = cleanText(body.email, 254).toLowerCase();
      if (!validEmail(email)) return json(400, { error: "Informe um e-mail válido." });
      await db.insert(newsletter).values({ email }).onConflictDoNothing();
      return json(201, { ok: true });
    }

    if (req.method === "POST" && route === "/api/adoptions") {
      const adoption = {
        name: cleanText(body.name, 100),
        phone: cleanText(body.phone, 30),
        city: cleanText(body.city, 100),
        message: cleanText(body.message, 1000),
        pet: cleanText(body.pet, 80),
      };
      if (Object.values(adoption).some((value) => !value)) return json(400, { error: "Preencha todos os campos." });
      await db.insert(adoptions).values({ id: createId(), ...adoption });
      return json(201, { ok: true });
    }

    if (req.method === "GET" && route === "/api/reports") {
      const rows = await db.select(reportColumns).from(reports).orderBy(desc(reports.createdAt));
      return json(200, { reports: rows });
    }
    if (req.method === "POST" && route === "/api/reports") {
      const report = {
        status: body.status === "encontrado" ? "encontrado" : "perdido",
        name: cleanText(body.name, 100),
        animal: cleanText(body.animal, 40),
        location: cleanText(body.location, 150),
        description: cleanText(body.description, 1000),
        photo: cleanText(body.photo, 2_000_000),
        date: cleanText(body.date, 20),
      };
      if ([report.name, report.animal, report.location, report.description, report.date].some((value) => !value)) {
        return json(400, { error: "Preencha todos os campos da ocorrência." });
      }
      if (Number.isNaN(Date.parse(report.date))) return json(400, { error: "Informe uma data válida." });
      const [saved] = await db
        .insert(reports)
        .values({ id: createId(), ...report, photo: report.photo || null, dateLabel: "agora" })
        .returning(reportColumns);
      return json(201, { report: saved });
    }

    if (req.method === "POST" && route === "/api/donations") {
      const donation = {
        name: cleanText(body.name, 100),
        email: cleanText(body.email, 254).toLowerCase(),
        amountCents: Number(body.amount),
      };
      if (donation.name.length < 2 || !validEmail(donation.email) || !validDonationAmount(donation.amountCents)) {
        return json(400, { error: "Informe nome, e-mail válido e um dos valores disponíveis." });
      }
      await db.insert(donations).values({ id: createId(), ...donation });
      return json(201, { ok: true, status: "intencao-registrada" });
    }

    if (req.method === "GET" && route === "/api/wiki/articles") {
      const rows = await db.select(articleColumns).from(wikiArticles).orderBy(desc(wikiArticles.createdAt));
      return json(200, { articles: rows });
    }
    if (req.method === "POST" && route === "/api/wiki/articles") {
      const article = {
        title: cleanText(body.title, 180),
        category: cleanText(body.category, 20),
        author: cleanText(body.author, 100),
        summary: cleanText(body.summary, 1000),
      };
      if (article.title.length < 4 || !validWikiCategory(article.category) || article.author.length < 2 || article.summary.length < 10) {
        return json(400, { error: "Preencha título, categoria, autor e um resumo com pelo menos 10 caracteres." });
      }
      const [saved] = await db.insert(wikiArticles).values({ id: createId(), ...article }).returning(articleColumns);
      return json(201, { article: saved });
    }

    if (req.method === "POST" && route === "/api/testimonials") {
      const testimonial = { name: cleanText(body.name, 100), role: cleanText(body.role, 120), text: cleanText(body.text, 2000) };
      if (testimonial.name.length < 2 || testimonial.role.length < 2 || testimonial.text.length < 10) {
        return json(400, { error: "Preencha seu nome, identificação e um depoimento com pelo menos 10 caracteres." });
      }
      await db.insert(testimonials).values({ id: createId(), ...testimonial });
      return json(201, { ok: true, status: "em-analise" });
    }

    if (req.method === "GET" && route === "/api/stats") {
      const [[pets], [adoptionCount], [donated]] = await Promise.all([
        db.select({ value: count() }).from(reports).where(eq(reports.status, "encontrado")),
        db.select({ value: count() }).from(adoptions),
        db.select({ value: sql<string>`COALESCE(SUM(${donations.amountCents}), 0)` }).from(donations),
      ]);
      return json(200, {
        pets: Number(pets.value),
        adoptions: Number(adoptionCount.value),
        campaigns: 3, // não há tabela de campanhas no banco ainda; valor fixo igual ao número de campanhas exibidas no site
        donatedCents: Number(donated.value),
      });
    }

    return json(404, { error: "Rota não encontrada." });
  } catch (error) {
    console.error(error);
    return json(500, { error: "Erro interno do servidor." });
  }
};

export const config: Config = {
  path: "/api/*",
};
