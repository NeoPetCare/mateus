CREATE TABLE "adoptions" (
	"id" text PRIMARY KEY,
	"name" varchar(100) NOT NULL,
	"phone" varchar(30) NOT NULL,
	"city" varchar(100) NOT NULL,
	"message" varchar(1000) NOT NULL,
	"pet" varchar(80) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "donations" (
	"id" text PRIMARY KEY,
	"name" varchar(100) NOT NULL,
	"email" varchar(254) NOT NULL,
	"amount_cents" integer NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "donations_amount_cents_check" CHECK ("amount_cents" > 0)
);
--> statement-breakpoint
CREATE TABLE "newsletter" (
	"email" varchar(254) PRIMARY KEY,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reports" (
	"id" text PRIMARY KEY,
	"status" varchar(20) NOT NULL,
	"name" varchar(100) NOT NULL,
	"animal" varchar(40) NOT NULL,
	"location" varchar(150) NOT NULL,
	"description" varchar(1000) NOT NULL,
	"photo" text,
	"date" date NOT NULL,
	"date_label" varchar(40) DEFAULT 'agora' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "reports_status_check" CHECK ("status" IN ('perdido', 'encontrado'))
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"token" text PRIMARY KEY,
	"user_id" text NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "testimonials" (
	"id" text PRIMARY KEY,
	"name" varchar(100) NOT NULL,
	"role" varchar(120) NOT NULL,
	"text" varchar(2000) NOT NULL,
	"status" varchar(20) DEFAULT 'em-analise' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "testimonials_status_check" CHECK ("status" IN ('em-analise', 'aprovado'))
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY,
	"name" varchar(100) NOT NULL,
	"email" varchar(254) NOT NULL UNIQUE,
	"password_hash" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "wiki_articles" (
	"id" text PRIMARY KEY,
	"title" varchar(180) NOT NULL,
	"category" varchar(20) NOT NULL,
	"author" varchar(100) NOT NULL,
	"summary" varchar(1000) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "wiki_articles_category_check" CHECK ("category" IN ('saude', 'cuidados', 'adocao', 'direitos'))
);
--> statement-breakpoint
CREATE INDEX "reports_created_at_idx" ON "reports" ("created_at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "sessions_user_id_idx" ON "sessions" ("user_id");--> statement-breakpoint
CREATE INDEX "testimonials_created_at_idx" ON "testimonials" ("created_at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "wiki_articles_created_at_idx" ON "wiki_articles" ("created_at" DESC NULLS LAST);--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;